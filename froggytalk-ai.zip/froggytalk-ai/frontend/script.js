document.getElementById("userForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
        full_name: document.getElementById("full_name").value,
        origin: document.getElementById("origin").value,
        residence: document.getElementById("residence").value,
        purpose: document.getElementById("purpose").value,
        language: document.getElementById("language").value
    };

    const model = document.getElementById("modelType").value;
    const endpoint = model === "base" ? "generate" : "generate-trained";

    try {
        // Collect user data
        await fetch("http://127.0.0.1:8000/collect", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        // Generate AI response
        const res = await fetch(`http://127.0.0.1:8000/${endpoint}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        const result = await res.json();

        // Format response nicely
        let formatted = `
Personalized Summary: ${result.personalized_summary}

Career Recommendations: ${result.career_recommendations}

Skill Gaps: ${result.skill_gaps}

Improvement Strategy: ${result.improvement_strategy}

Confidence Score: ${result.confidence_score}
        `;

        const responseArea = document.getElementById("responseArea");
        responseArea.innerText = formatted;

        // Scroll user to response
        responseArea.scrollIntoView({ behavior: "smooth" });

        // Keep the response visible indefinitely
        // Optionally disable form during display
        document.getElementById("userForm").reset(); // only clears form inputs, not response
    } catch (err) {
        console.error(err);
        alert("Error connecting to backend");
    }

    return false; // ensures nothing else clears the response
});
