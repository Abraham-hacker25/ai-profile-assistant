from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import os

from services import generate_base_response, generate_trained_response, train_model

app = FastAPI()

# CORS fix
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class UserInfo(BaseModel):
    full_name: str
    origin: str
    residence: str
    purpose: str
    language: str

class GenerateRequest(BaseModel):
    use_trained: bool = False

# Ensure users.json exists
if not os.path.exists("users.json"):
    with open("users.json", "w") as f:
        json.dump([], f)

@app.get("/health-servercheck")
def health():
    return {"status": "ok"}

@app.post("/collect")
def collect_user(data: UserInfo):
    with open("users.json", "r") as f:
        users = json.load(f)
    users.append(data.dict())
    with open("users.json", "w") as f:
        json.dump(users, f, indent=4)
    return {"status": "success", "message": "User saved successfully!"}

@app.post("/train")
def train():
    train_model()
    return {"status": "success", "message": "Pseudo-training complete."}

@app.post("/generate")
def generate(data: UserInfo):
    return generate_base_response(data)

@app.post("/generate-trained")
def generate_trained(data: UserInfo):
    return generate_trained_response(data)
