import json
import os

# Base model response
def generate_base_response(user):
    return {
        "personalized_summary": f"Hello {user.full_name}, this is a generic AI response.",
        "career_recommendations": "Focus on skill improvement.",
        "skill_gaps": "Basic skills gap analysis.",
        "improvement_strategy": "Study and practice daily.",
        "confidence_score": 0.5
    }

# Trained model response (pseudo-trained)
def generate_trained_response(user):
    return {
        "personalized_summary": f"Hi {user.full_name}! Since you're from {user.origin} and want {user.purpose}, here's tailored advice.",
        "career_recommendations": f"Focus on {user.language} skills and explore opportunities in {user.residence}.",
        "skill_gaps": "Improvement needed in key job skills.",
        "improvement_strategy": "Take online courses, network, and practice projects.",
        "confidence_score": 0.9
    }

# Pseudo-train model (mock function)
def train_model():
    # In real scenario, this would fine-tune the model
    if not os.path.exists("users.json"):
        return
    with open("users.json", "r") as f:
        users = json.load(f)
    # Just simulate training
    print(f"Training on {len(users)} users...")
