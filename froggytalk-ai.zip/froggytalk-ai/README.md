# FroggyTalk — Mini Prototype

## Overview
FroggyTalk is a small prototype of a personalized AI assistant that:
- Collects user profiles via a frontend form
- Stores profiles locally (JSON)
- Generates personalized messages using a base LLM
- Creates synthetic training data and runs a pseudo-training pipeline
- Exposes a trained/adapted model (simulated via adapter.json)

## Tech stack
- Backend: FastAPI (Python)
- Frontend: Plain HTML + JS
- Storage: Local JSON (`backend/data/users.json`)
- LLM: Optional OpenAI; script supports pseudo-LLM fallback

## Endpoints
- `POST /collect` — save user profile
- `POST /generate` — generate using base model
- `POST /train` — run pseudo-training (produces `adapter.json`)
- `POST /generate-trained` — generate using trained adapter
- `GET /health-servercheck` — health check

## How to run (local)
1. Backend:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate      # or .venv\\Scripts\\activate on Windows
pip install -r requirements.txt
uvicorn app:app --reload --host 0.0.0.0 --port 8000
